# 关于我
这是 Red Kold，一个 CS/Fin-tech 学生的个人笔记仓库。可能也会出现个人爱好（BanG Dream，MAD 制作）等笔记内容。
笔记也可以在线查看，基于 mkdocs. 链接：[RedKold Note](https://redkold.github.io/redkoldnote)
