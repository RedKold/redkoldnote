[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/AcSfnCh2)
# ProblemSet1 宝宝巴士

-  1.2，1.3，1.7，1.8，1.9，1.10
-  2.2，2.5，2.7，2.8，2.16(有些写不出来没关系，尽自己所能)，2.18，2.19，2.22，2.24
-  3.2，3.5，3.6，3.8，3.9

习题出处：算法设计与分析 （黄宇） 第 2 版

电子版同学自行将作业整合成一份pdf文件，通过classroom提交作业
