# 关于我

我是 Red Kold. 

Bilibili ：[Red_Kold 的个人空间](https://space.bilibili.com/23341766) 

南京大学-计算机金融实验班大二

击碎跃动的梦想。
![image.png|400](https://kold.oss-cn-shanghai.aliyuncs.com/20250616122939.png)


- 热烈祝贺 poppin' party 来华演出！
<iframe allow="autoplay *; encrypted-media *;" frameborder="0" height="150" style="width:100%;max-width:660px;overflow:hidden;background:transparent;" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-storage-access-by-user-activation allow-top-navigation-by-user-activation" src="https://embed.music.apple.com/cn/album/star-beat-%E3%83%9B%E3%82%B7%E3%83%8E%E3%82%B3%E3%83%89%E3%82%A6/1801184614?i=1801184623"></iframe>
