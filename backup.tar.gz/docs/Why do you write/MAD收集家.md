# MAD 收藏家
## 自己的想法
 ## AJR - I' m Weak
 这首歌的主旨是接受悦纳自己的软弱，并以此转化为能量向未来开战。是否合适 Sakiko?
 ## 荣耀为我俯首
 于连式的背负自己的人生向前走。如果可能最好能做成填词和 AMV 结合。Sakiko 
## MyGO!!!!!
[[MyGO/误解向]"这一次，从开头奔向你"_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV13rkFYNEXH)
评语：
这部作品是绝对的佳作！其对画幅、比例的应用出神入化——无论是使用画幅分割体现爱素之间的隔阂，还是利用走出画幅的高松灯来突出情感。作品还充分利用了主角的动作作为视觉元素（例如开门、使用手机）等作为转场的载体，有一种打破“第三堵墙”的奇效。似乎在画面中活动的小爱音和小爽世是他们内心的外化一样。移花接木并不罕见的今天，这部作品对原有剧情的重组和元素的拼接达到了一种“漫画”式的重新创作效果，非常震撼，非常喜欢！

[【MAD|剧情向】小石头の诗【It's MyGO!!!!!】_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1RmBiYcEsG/)
评语：原汤化原食。对诗超绊的歌曲节奏掌握得很好，虽说是简单的根据原剧情叙事，但是巧妙的闪回和画面组织，使得在原版已经足够感人的 live 基础上继续升华!

[【素祥/误解向】又幻想了，幻想「后来的我们」能在一起_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1G296YGEM2/?spm_id_from=333.788.recommend_more_video.-1&vd_source=920be8552f568c8d5ea73154e2bccb12)

[【灯祥/MAD】“我不擦去你名字不可”_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV19iN9e1ECh/?spm_id_from=333.337.search-card.all.click&vd_source=920be8552f568c8d5ea73154e2bccb12)







